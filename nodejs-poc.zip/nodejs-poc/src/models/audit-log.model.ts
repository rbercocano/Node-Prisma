export interface AuditLog {
    clientId: string;
}