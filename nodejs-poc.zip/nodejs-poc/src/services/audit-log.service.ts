import { AuditLog } from "../models/audit-log.model";
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient({
    log: ["query"]
  })
export const find = async (id: string): Promise<AuditLog[]> => {

    await prisma.$connect();
    var x = await prisma.auditlog.create({ data: { clientId: '1231283', oldValue: '133', newValue: '1222' } });
    const allUsers:AuditLog[] = await prisma.auditlog.findMany();
    console.log(allUsers);
    return allUsers;
};  