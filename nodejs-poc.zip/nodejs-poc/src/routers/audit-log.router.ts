
import express, { Request, Response } from "express";
import { AuditLog } from "../models/audit-log.model";
import *  as AuditLogService from "../services/audit-log.service"

export const auditLogRouter = express.Router();

auditLogRouter.get("/:id", async (req: Request, res: Response) => {
    try {
        let auditLogs: AuditLog[] = await AuditLogService.find(req.params.id);
        if (auditLogs.length > 0)
            res.status(200).send(auditLogs);
        else
            res.status(404).send([]);
    } catch (e: any) {
        res.status(500).send(e.message);
    }
});